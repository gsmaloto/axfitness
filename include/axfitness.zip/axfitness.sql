/*
SQLyog Enterprise - MySQL GUI v8.12 
MySQL - 5.5.5-10.4.21-MariaDB : Database - ax
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`ax` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `ax`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `role` int(11) DEFAULT NULL,
  `username` varchar(34) NOT NULL,
  `firstName` varchar(25) DEFAULT NULL,
  `lastName` varchar(25) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(34) NOT NULL,
  `picture` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

/*Data for the table `admin` */

insert  into `admin`(`id`,`role`,`username`,`firstName`,`lastName`,`email`,`password`,`picture`) values (6,1,'admin','jr ','pleto','admin@gmail.com','7815696ecbf1c96e6894b779456d330e','img/c.jpg'),(7,0,'user','Joy','Capungan','receptionist@gmail.com','7815696ecbf1c96e6894b779456d330e','img/e.jpg'),(12,NULL,'Ghgh','ghgh','ghgh','ghgh@sasdf','d41d8cd98f00b204e9800998ecf8427e',''),(13,NULL,'vvv','Vvvv','Vvvv','vvv@vvvv','d41d8cd98f00b204e9800998ecf8427e',''),(14,NULL,'lll','Llllll','Llllll Lllll','lll@lll','d41d8cd98f00b204e9800998ecf8427e','');

/*Table structure for table `appoint` */

DROP TABLE IF EXISTS `appoint`;

CREATE TABLE `appoint` (
  `appId` int(12) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `clientId` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `payment` varchar(30) NOT NULL,
  `created` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`appId`)
) ENGINE=InnoDB AUTO_INCREMENT=462 DEFAULT CHARSET=utf8mb4;

/*Data for the table `appoint` */

insert  into `appoint`(`appId`,`code`,`clientId`,`date`,`time`,`status`,`payment`,`created`) values (408,'0216c3e536b005b5b7fd7553d40d92ab',0,'2021-11-24','PM','cancel','Cash','2021-11-13 06:28:42'),(409,'c9b4762fa320d25283d5593626c60180',0,'2021-11-13','AM','cancel','Cash','2021-11-13 09:42:57'),(459,'5ffc6259b354d73c1b22fd8ac4d1d74e',58,'2021-11-19','AM','approve','Gcash','2021-11-14 10:41:44'),(460,'d4578ff6a609664b743475c94e53d0ee',59,'2021-11-19','AM','cancel','Gcash','2021-11-19 10:54:28'),(461,'627f1f4afe77002809e70fd60dd70f7b',60,'2021-11-19','PM','cancel','Cash','2021-11-19 11:11:33');

/*Table structure for table `blog_post` */

DROP TABLE IF EXISTS `blog_post`;

CREATE TABLE `blog_post` (
  `blog_id` int(10) NOT NULL AUTO_INCREMENT,
  `blog_title` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `picture` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`blog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `blog_post` */

insert  into `blog_post`(`blog_id`,`blog_title`,`description`,`picture`,`created`) values (2,'hellohi','hello','image/loading_indicator.gif','2021-11-05 16:09:46');

/*Table structure for table `client` */

DROP TABLE IF EXISTS `client`;

CREATE TABLE `client` (
  `clientId` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `contactNo` varchar(50) NOT NULL,
  `address` varchar(250) DEFAULT NULL,
  `medicine` varchar(50) NOT NULL,
  `condition` varchar(50) NOT NULL,
  `goals` varchar(50) NOT NULL,
  `pregnant` varchar(50) NOT NULL,
  `civilStatus` varchar(50) NOT NULL,
  `emName` varchar(50) NOT NULL,
  `emContact` varchar(50) NOT NULL,
  `payment` varchar(50) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `code` text DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`clientId`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4;

/*Data for the table `client` */

insert  into `client`(`clientId`,`username`,`password`,`firstName`,`lastName`,`email`,`gender`,`contactNo`,`address`,`medicine`,`condition`,`goals`,`pregnant`,`civilStatus`,`emName`,`emContact`,`payment`,`picture`,`code`,`created`) values (53,'Cena','7815696ecbf1c96e6894b779456d330e','John','Cena','j.pleto321@gmail.com','male','093254332456','Santa Cruz','','','','','','','','','','',NULL),(54,'jblulate','fc4a8568957a41a66d07b050dd56d8d3','Jojo','Bulate','jblulate@gmail.com','male','093254332887','Santa Cruz Laguna','','','','','','','','','','07f3751d1205b283dc55ba9fb87f3b75',NULL),(55,'adamcole','d5cbfe9ff07fef1ecc93861ce5dd4f3b','Adam','Cole','acole@gmail.com','male','093254332443','Calamba','','','','','','','','','','89987d84571d52e52397a2cc369ce360',NULL),(56,'komega','2f27ec7dbc36a3717847b28c4ac61acb','Kenny','Omega','komega32@gmail.com','male','093254332111','Santa Cruz Laguna','','','','','','','','','','53d95c52e4cb0ce33fb91b977a3e25fe',NULL),(60,'gsmaloto','7815696ecbf1c96e6894b779456d330e','gener','maloto','genermaloto@gmail.com','male','09877765678','Sta. Cruz, Laguna','','','','','','','','','A.jpg','ad81e1de895efcb3ef49dfbaf322b81a',NULL);

/*Table structure for table `comment` */

DROP TABLE IF EXISTS `comment`;

CREATE TABLE `comment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `names` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `message` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `comment` */

insert  into `comment`(`id`,`names`,`email`,`website`,`picture`,`message`,`created`) values (1,'aw','aw@gmail.com','awaw','img/image-5.png','koko','2021-11-09 20:56:35'),(2,'aw','aw@gmail.com','awaw','img/image-5.png','koko','2021-11-09 20:56:35');

/*Table structure for table `equipment` */

DROP TABLE IF EXISTS `equipment`;

CREATE TABLE `equipment` (
  `equipId` int(10) NOT NULL AUTO_INCREMENT,
  `equipName` varchar(50) NOT NULL,
  `equipBrand` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `picture` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`equipId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

/*Data for the table `equipment` */

insert  into `equipment`(`equipId`,`equipName`,`equipBrand`,`price`,`description`,`picture`,`created`) values (1,' awts','  awts',' 35',' hehe','img/image-6.png','2021-11-05 15:55:37');

/*Table structure for table `event` */

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `eventId` int(12) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `detail` varchar(500) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`eventId`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4;

/*Data for the table `event` */

insert  into `event`(`eventId`,`date`,`time`,`title`,`detail`,`status`,`created`) values (46,'2020-11-11','14:18:48','takbuhan','fun run in Ax Fitness                   ','active','2021-11-13 14:18:45');

/*Table structure for table `healthdeclaration` */

DROP TABLE IF EXISTS `healthdeclaration`;

CREATE TABLE `healthdeclaration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientId` int(11) DEFAULT NULL,
  `q1` varchar(11) DEFAULT NULL,
  `q2` varchar(11) DEFAULT NULL,
  `q3` varchar(11) DEFAULT NULL,
  `q4` varchar(11) DEFAULT NULL,
  `q5` varchar(50) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

/*Data for the table `healthdeclaration` */

insert  into `healthdeclaration`(`id`,`clientId`,`q1`,`q2`,`q3`,`q4`,`q5`,`created`) values (1,38,'Yes','Yes','Yes','Yes','tes','2021-11-18 13:18:42'),(2,38,'Yes','Yes','No','No','ggg','2021-11-18 13:20:41'),(3,38,'No','No','No','No','Santa Cruz','2021-11-18 16:23:34'),(4,38,'Yes','No','Yes','No','Liliw','2021-11-18 18:01:36'),(5,38,'Yes','No','No','No','calamba','2021-11-18 18:51:47'),(6,52,'Yes','No','No','No','calamba','2021-11-18 18:58:29'),(7,38,'No','No','No','No','','2021-11-19 11:57:58'),(8,38,'No','No','No','No','','2021-11-19 13:28:38'),(9,58,'No','No','No','No','','2021-11-19 16:54:27'),(10,58,'No','No','No','No','','2021-11-19 17:06:40'),(11,58,'No','No','No','No','','2021-11-19 17:10:47'),(12,58,'No','No','No','No','','2021-11-19 17:41:44'),(13,59,'No','No','No','No','','2021-11-19 17:54:28'),(14,60,'No','No','No','No','','2021-11-19 18:11:33');

/*Table structure for table `location` */

DROP TABLE IF EXISTS `location`;

CREATE TABLE `location` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `location` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `maxAM` int(5) NOT NULL,
  `maxPM` int(5) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

/*Data for the table `location` */

insert  into `location`(`id`,`location`,`description`,`maxAM`,`maxPM`,`date_created`,`date_updated`) values (1,'ax','&lt;p&gt;Sample only&lt;/p&gt;',20,100,'2021-06-28 16:19:10',NULL);

/*Table structure for table `notif` */

DROP TABLE IF EXISTS `notif`;

CREATE TABLE `notif` (
  `id` int(11) NOT NULL,
  `fromId` int(11) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `detail` varchar(30) DEFAULT NULL,
  `status` int(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `notif` */

insert  into `notif`(`id`,`fromId`,`title`,`detail`,`status`) values (0,36,NULL,'asd314',0),(1,36,'adasd','asdasdasd',0),(2,36,'sdasd','asdasd',0),(3,36,'asdasd','asdasd',1),(4,36,NULL,NULL,1);

/*Table structure for table `sitesetting` */

DROP TABLE IF EXISTS `sitesetting`;

CREATE TABLE `sitesetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `coverImg` varchar(100) DEFAULT NULL,
  `about` varchar(500) NOT NULL,
  `max` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `sitesetting` */

insert  into `sitesetting`(`id`,`name`,`email`,`contact`,`coverImg`,`about`,`max`) values (1,'  AX Fitness1234','  axfitnessgyms@gmail.com','  09xxxxxxxxx','asdasdasd','aboutaboutaboutaboutaboutaboutaboutaboutaboutabout',10);

/*Table structure for table `videogallery` */

DROP TABLE IF EXISTS `videogallery`;

CREATE TABLE `videogallery` (
  `video_id` int(50) NOT NULL AUTO_INCREMENT,
  `video_name` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  PRIMARY KEY (`video_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

/*Data for the table `videogallery` */

insert  into `videogallery`(`video_id`,`video_name`,`description`,`location`) values (1,'awa','			aw					','../video/202111051636088092.mp4');

/*Table structure for table `webdetail` */

DROP TABLE IF EXISTS `webdetail`;

CREATE TABLE `webdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `coverImg` varchar(100) DEFAULT NULL,
  `about` varchar(500) NOT NULL,
  `max` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `webdetail` */

insert  into `webdetail`(`id`,`name`,`email`,`contact`,`coverImg`,`about`,`max`) values (1,'AX Fitness PH','axfitnessphilippines@gmail.com','0918 652 9383','asdasdasd','AX Fitness was established May 1, 2013 and the owner is Mr. Gerard Palacol.\r\n\r\n\"Make your body your machine\"',10);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
